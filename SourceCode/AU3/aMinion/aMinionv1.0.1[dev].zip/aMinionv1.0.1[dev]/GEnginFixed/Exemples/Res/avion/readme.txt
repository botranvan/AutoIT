Aucune des ces ressources ne sont de moi!
� chaqu'une son propri�taire, elle ne sont l� qu'� titre d'exemple
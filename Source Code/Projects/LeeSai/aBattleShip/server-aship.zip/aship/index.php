﻿<?php
	$page_title= "Homepage";
	include "./include/header.inc";
	include "./include/homepage.inc";
	include "./include/footer.inc";
?>